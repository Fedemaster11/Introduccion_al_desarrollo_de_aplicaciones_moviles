//
//  Actividad_1App.swift
//  Actividad 1
//
//  Created by Luis Maco on 25.01.26.
//

import SwiftUI

@main
struct Actividad_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
